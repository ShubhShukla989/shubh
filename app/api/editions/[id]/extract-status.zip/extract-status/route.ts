import { NextRequest, NextResponse } from 'next/server';
import { extractionQueue } from '@/lib/queues/extractionQueue';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const jobId = request.nextUrl.searchParams.get('jobId');
  if (!jobId) return NextResponse.json({ error: 'Missing jobId' }, { status: 400 });

  const job = await extractionQueue.getJob(jobId);
  if (!job) return NextResponse.json({ error: 'Job not found' }, { status: 404 });

  const state = await job.getState();
  const progress = typeof job.progress === 'number' ? job.progress : 0;

  if (state === 'completed') {
    return NextResponse.json({
      status: 'done',
      progress: 100,
      message: `Extracted ${job.returnvalue?.pageCount} pages`,
      result: job.returnvalue,
    });
  }

  if (state === 'failed') {
    return NextResponse.json({
      status: 'error',
      progress: 0,
      error: job.failedReason || 'Extraction failed',
    });
  }

  const messages: Record<number, string> = {
    10: 'Reading PDF...',
    20: 'Extracting pages via Ghostscript...',
    50: 'Pages extracted, generating thumbnails...',
    60: 'Generating thumbnails in parallel...',
    90: 'Saving to database...',
    100: 'Done!',
  };

  const message = messages[progress] || `Processing... ${progress}%`;

  return NextResponse.json({ status: 'processing', progress, message });
}
